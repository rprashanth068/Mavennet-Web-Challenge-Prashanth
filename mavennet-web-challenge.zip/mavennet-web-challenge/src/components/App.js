import React from 'react';
import './App.scss';
import { BrowserRouter, Route } from 'react-router-dom';
import Header from './header/Header';
import Login from './login/Login';
import Home from './home/Home';

class App extends React.Component {
  render() {
    return (
      <BrowserRouter>
        <Route>
          <div className="app container-fluid">
            <Header />
            <Route exact path="/" component={Login} />
            <Route exact path="/home" component={Home} />
          </div>
        </Route>
      </BrowserRouter>
    );
  }
}

export default App;
