import React from 'react';
import './header.scss';
import { Navbar, Nav, NavDropdown, Form } from 'react-bootstrap';

class Login extends React.Component {

  constructor() {
    super();
    const userName = sessionStorage.getItem("userName");
    this.state = {
      isUserLoggedIn: userName ? true:false,
      userName: userName ? userName:'Guest',
      emailId: sessionStorage.getItem("emailId")
    };
    this.logout = this.logout.bind(this);
  }

  logout = () => {
    sessionStorage.removeItem("emailId");
    sessionStorage.removeItem("userName");
    sessionStorage.removeItem("userId");
    window.location.reload();
  }

  render() {
    const { userName, emailId } = this.state;
    return (
      <Navbar bg="light" expand="lg">
        <Navbar.Brand href="home">Mavennet Web Challenge</Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="mr-auto">
            { emailId && <Nav.Link href="home">Home</Nav.Link> }
          </Nav>
          <Form inline>
            <NavDropdown title={'Welcome, ' + userName} id="basic-nav-dropdown">
              <NavDropdown.Item href="#" onClick={this.logout}>Logout</NavDropdown.Item>
            </NavDropdown>
          </Form>
        </Navbar.Collapse>
      </Navbar>
    );
  }

}

export default Login;
