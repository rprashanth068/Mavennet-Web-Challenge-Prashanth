import React from 'react';
import './home.scss';
import { getAlbums, getPhotos } from './../../services/api-util';
import { Card } from 'react-bootstrap';

class Home extends React.Component {

  constructor() {
    super();
    this.state = {
      albums: [],
      selectedAlbumId: null,
      photos: []
    };
  }

  componentWillMount() {
    if(!sessionStorage.getItem("userId")) {
      this.props.history.push('/');
    }
  }

  componentDidMount() {
    if(sessionStorage.getItem("userId")) {
      getAlbums(
        sessionStorage.getItem("userId"),
        (albums) => {
          this.setState({
            albums: albums,
            selectedAlbumId: albums[0].id,
            photos: []
          });
          this.getPhotos(albums[0].id);
        },
        () => {}
      );
    }
  }

  getPhotos = (albumId) => {
    getPhotos(
      albumId,
      (photos) => {
        this.setState({
          photos: photos
        });
      },
      () => {}
    );
  }

  onAlbumSelected = (albumId) => {
    this.setState({
      selectedAlbumId: albumId
    });
    this.getPhotos(albumId);
  }

  render() {
    const { albums, selectedAlbumId, photos } = this.state;
    return (
      <div className="home row">
        <div className="col-md-2 albums">
          {
            // can be extracted to seperate component as Album.js so that we can reuse every where
            albums.map((album, index) => <div key={index} className={"album " + (album.id===selectedAlbumId ? 'selected' : '')} onClick={this.onAlbumSelected.bind(this, album.id)}>{album.title}</div>)
          }
        </div>
        <div className="col-md-10 photos">
          {
            // can be extracted to seperate component as Photo.js so that we can reuse every where
            photos.map((photo, index) => 
              <Card key={index} className="photo">
                <Card.Img variant="top" src={photo.thumbnailUrl} />
                <Card.Body>
                  <Card.Title>{photo.title}</Card.Title>
                </Card.Body>
              </Card>
            )
          }
        </div>
      </div>
    );
  }
}

export default Home;
