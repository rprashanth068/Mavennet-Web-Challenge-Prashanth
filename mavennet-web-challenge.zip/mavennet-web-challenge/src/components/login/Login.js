import React from 'react';
import './login.scss';
import { Form, Button } from 'react-bootstrap';
import { getUser } from './../../services/api-util';

class Login extends React.Component {

  constructor() {
    super();
    this.state = {
      errorMsg: null
    };
    this.handleInputChange = this.handleInputChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleInputChange = (event) => {
    this.setState({emailId: event.target.value});
  }

  handleSubmit = () => {
    const { emailId } = this.state;
    if(emailId && emailId.trim().length > 0) {
      getUser(
        emailId.trim(),
        (result) => {
          if(result.length > 0) {
            sessionStorage.setItem("emailId", result[0].email);
            sessionStorage.setItem("userId", result[0].id);
            sessionStorage.setItem("userName", result[0].name);
            this.props.history.push('/home');
            window.location.reload();
          } else {
            this.setState({
              errorMsg: 'Email ID not found or wrong, please try again.'
            });
          }
        },
        (error) => {
          this.setState({
            errorMsg: 'Email ID not found or wrong, please try again.'
          });
        }
      );
    }
  }

  render() {
    return (
      <Form className="login-form col-md-4 offset-md-4">
        <div className="login-title">Login to see your Albums</div>
        <Form.Group controlId="formBasicEmail">
          <Form.Control type="email" placeholder="Enter email" onChange={this.handleInputChange} required/>
          <Form.Text className="text-muted error-msg">
            {this.state.errorMsg}
          </Form.Text>
          <Button variant="primary" className="login-btn" onClick={this.handleSubmit}>
            Go
          </Button>
        </Form.Group>
      </Form>
    );
  }

}

export default Login;
