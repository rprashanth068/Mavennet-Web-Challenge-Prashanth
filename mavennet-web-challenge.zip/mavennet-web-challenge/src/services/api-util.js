const API_URL_BASE = 'https://jsonplaceholder.typicode.com/';
const API_URL_GET_USER = API_URL_BASE + 'users?email=';
const API_URL_GET_ALBUMS = API_URL_BASE + 'albums?userId=';
const API_URL_GET_PHOTOS = API_URL_BASE + 'photos?albumId=';

const getUser = (emailId, successCallback, errorCallback) => {
	fetch(API_URL_GET_USER + emailId)
	  .then(res => res.json())
	  .then(successCallback, errorCallback);
};

const getAlbums = (userId, successCallback, errorCallback) => {
	fetch(API_URL_GET_ALBUMS + userId)
	  .then(res => res.json())
	  .then(successCallback, errorCallback);
};

const getPhotos = (albumId, successCallback, errorCallback) => {
	fetch(API_URL_GET_PHOTOS + albumId)
	  .then(res => res.json())
	  .then(successCallback, errorCallback);
};

export {
	getUser,
	getAlbums,
	getPhotos
};